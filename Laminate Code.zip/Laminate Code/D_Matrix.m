function D = D_Matrix(QbarVec,tvec,zvec)
    
D = zeros(3,3);

for i = 1:length(QbarVec)
    tempD = D + QbarVec{i}*(tvec(i)*zvec(i)^2+(tvec(i)^3/12));
    D = tempD;
end

end