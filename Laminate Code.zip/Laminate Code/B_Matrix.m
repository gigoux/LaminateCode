function B = B_Matrix(QbarVec,tvec,zvec)
    
B = zeros(3,3);

for i = 1:length(QbarVec)
    tempB = B + QbarVec{i}*tvec(i)*zvec(i);
    B = tempB;
end

end
