function QbarTotal = Qbar_Laminate(E1, E2, G12, nu12, nu21, thetavec)

%Defining Compliance Matrix
S = [1/E1, -nu21/E2, 0; -nu12/E1, 1/E2, 0; 0, 0, 1/G12];
%Defining Reduced Stiffness Matrix as Compliance Matrix Inverse
Q = inv(S);

%Creating a cell to hold the Qbar for each ply orientation
QbarTotal = cell(length(thetavec), 1);

for i = 1:length(thetavec)
    %Defining Strain Transformation Matrix for the ply
    T_eps = [cosd(thetavec(i))^2, sind(thetavec(i))^2, cosd(thetavec(i))*sind(thetavec(i)); ...
    sind(thetavec(i))^2, cosd(thetavec(i))^2, -cosd(thetavec(i))*sind(thetavec(i)); ...
    -2*cosd(thetavec(i))*sind(thetavec(i)), 2*cosd(thetavec(i))*sind(thetavec(i)), cosd(thetavec(i))^2 - sind(thetavec(i))^2];

    QbarTotal{i} = transpose(T_eps)*Q*T_eps; 
end

end