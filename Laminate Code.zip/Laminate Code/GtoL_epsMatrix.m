function GtLMatrix = GtoL_epsMatrix(GMatrix, thetavec)

GtLMatrix = cell(length(thetavec), 1);

for i = 1:length(thetavec)
    T_eps = [cosd(thetavec(i))^2, sind(thetavec(i))^2, cosd(thetavec(i))*sind(thetavec(i)); ...
    sind(thetavec(i))^2, cosd(thetavec(i))^2, -cosd(thetavec(i))*sind(thetavec(i)); ...
    -2*cosd(thetavec(i))*sind(thetavec(i)), 2*cosd(thetavec(i))*sind(thetavec(i)), cosd(thetavec(i))^2 - sind(thetavec(i))^2];

    GtLMatrix{i} = T_eps*GMatrix;
end

end