function A = A_Matrix(QbarVec,tvec)
    
A = zeros(3,3);

for i = 1:length(QbarVec)
    tempA = A + QbarVec{i}*tvec(i);
    A = tempA;
end

end
    