function ABDinv = ABD_InvMatrix(A, B, D)
    ABDinv = cell(3, 1);

    delta = inv(D - B*inv(A)*B);
    beta = -inv(A)*B*delta;
    alpha = inv(A) + inv(A)*B*delta*B*inv(A);

    ABDinv{1} = alpha;
    ABDinv{2} = beta;
    ABDinv{3} = delta;
end