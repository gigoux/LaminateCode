clear;
clc;

%%Defining Material Properties

%Carbon Fiber
E1a = 9.4e6; %Youngs Modulus in Fiber Direction (lbf/in^2)
E2a = 9.4e6; %Youngs Modulus in Transverse Direction (lbf/in^2)
G12a = 0.45e6; %Shear Modulus (lbf/in^2)
nu12a = 0.046; %Poissons Ratio in Fiber Direction
nu21a = (E2a*nu12a) / E1a; %Poisonns Ratio in Transverse Direction
F1t_a = 114e3; %Longitudinal Tension (lbf/in^2)
F1c_a = 93e3; %Longitudinal Compression (lbf/in^2)
F2t_a = 114e3; %Transverse Tension (lbf/in^2)
F2c_a = 93e3; %Transverse Compression (lbf/in^2)
F12su_a = 10.4e3; %In-Plane Shear (lbf/in^2)

%Fiberglass
E1b = 3.5e6;
E2b = 3.5e6;
G12b = 0.77e6;
nu12b = 0.17;
nu21b = (E2b*nu12b) / E1b;
F1t_b = 53e3;
F1c_b = 80e3;
F2t_b = 53e3;
F2c_b = 80e3;
F12su_b = 14.1e3;



%%Ply Orientation for the Web (Carbon Fiber)

thetavec1 = [0 45 90 -45 -45 90 45 0]; %Ply Orientation (degrees)
tvec1 = 0.0084 * ones(1, 8); %Ply Thicknesses (m)
zvec1 = 0.0084 * [-4 -3 -2 -1 1 2 3 4]; %Centroid Distances (m)

QbarCell1 = Qbar_Laminate(E1a, E2a, G12a, nu12a, nu21a, thetavec1); %Reduced Stiffnesses
A1 = A_Matrix(QbarCell1, tvec1); %Extensional Stiffness Matrix (lbf/in)
B1 = B_Matrix(QbarCell1, tvec1, zvec1); %Coupling Stiffness Matrix (lbf)
B1 = zeros(3);
D1 = D_Matrix(QbarCell1, tvec1, zvec1); %Bending Stifness Matrix (lbf*in)

ABD1_Inv = ABD_InvMatrix(A1, B1, D1); %Matrix Inverses
alpha1 = ABD1_Inv{1};
beta1 = ABD1_Inv{2};
delta1 = ABD1_Inv{3};


%%Predefine loop conditions

strcond1a = 1; %testing longitudinal failure
strcond1b = 1; %testing transverse failure
strcond1c = 1; %testing in-plane shear failure
%Max shear is highest loading condition
%Max shear happens at beam midplane, where bending moment is 0
N1 = [0; 1; 0]; %lbs
M1 = [0; 0; 0]; %lbs*in

S1 = [1/E1a, -nu21a/E2a, 0; -nu12a/E1a, 1/E2a, 0; 0, 0, 1/G12a];

while strcond1a == 1 && strcond1b == 1 && strcond1c == 1
    
    %Define in-plane strains (eps0) and plate curvatures (kap)
    eps01 = alpha1*N1 + beta1*M1;
    kap1 = transpose(beta1)*N1 + delta1*M1;
    
    %Global Strains
    eps1G = cell(length(zvec1), 1);
    %Local Strains
    eps1L = cell(length(zvec1), 1);
    %Local Stresses
    sig1L = cell(length(zvec1), 1);    

    for i = 1:length(zvec1)

        eps1G{i} = eps01 + zvec1(i)*kap1;
        eps1L{i} = GtoL_epsMatrix(eps1G{i}, thetavec1(i));
        eps1L{i} = cell2mat(eps1L{i});
        sig1L{i} = S1\eps1L{i};

        %Longitudinal Failure (Tension or Compression)
        if abs(sig1L{i}(1)) >= F1t_a || abs(sig1L{i}(1)) >= F1c_a
            strcond1a = 0;
            break
        end

        %Transverse Failure (Tension or Compression)
        if abs(sig1L{i}(2)) >= F2t_a || abs(sig1L{i}(2)) >= F2c_a
            strcond1b = 0;
            break
        end

        %In-Plane Shear Failure
        if abs(sig1L{i}(3)) >= F12su_a
            strcond1c = 0;
            break
        end

    end

    N1 = N1 + [0; 1; 0];

end



%%Ply Orientation for the Flanges (Carbon Fiber + Fiberglass)

%Carbon Fiber
thetavec2 = thetavec1;
QbarCell2 = Qbar_Laminate(E1a, E2a, G12a, nu12a, nu21a, thetavec2);

%Fiberglass Section
thetavec3 = zeros(1, 8);
QbarCell3 = Qbar_Laminate(E1b, E2b, G12b, nu12b, nu21b, thetavec3);

%Combine the two in order of ply layup
tvec23 = [84 87 84 87 87 84 87 84] * 10^-4;
tvec23 = [tvec23 fliplr(tvec23)];
zvec23 = [-684 -600 -513 -429 -342 -255 -171 -84] * 10^-4;
zvec23 = [zvec23 -1*fliplr(zvec23)];
thetavec23 = [thetavec2(1) thetavec3(1) thetavec2(2) thetavec3(2) ...
    thetavec3(3) thetavec2(3) thetavec3(4) thetavec2(4)];
thetavec23 = [thetavec23 fliplr(thetavec23)];

QbarCell23 = cell(length(QbarCell2) + length(QbarCell3), 1);
L23 = length(QbarCell23)/2;
L2 = length(QbarCell2)/2;
L3 = length(QbarCell3)/2;

for i = 1:2
    QbarCell23{L23*i - 7} = QbarCell2{L2*i - 3};
    QbarCell23{L23*i - 6} = QbarCell3{L3*i - 3};
    QbarCell23{L23*i - 5} = QbarCell2{L2*i - 2};
    QbarCell23{L23*i - 4} = QbarCell3{L3*i - 2};
    QbarCell23{L23*i - 3} = QbarCell3{L3*i - 1};
    QbarCell23{L23*i - 2} = QbarCell2{L2*i - 1};
    QbarCell23{L23*i - 1} = QbarCell3{L3*i};
    QbarCell23{L23*i} = QbarCell2{L2*i};
end

A23 = A_Matrix(QbarCell23,tvec23);
B23 = B_Matrix(QbarCell23,tvec23,zvec23);
B23 = zeros(3);
D23 = D_Matrix(QbarCell23,tvec23,zvec23);

ABD23_Inv = ABD_InvMatrix(A23, B23, D23);
alpha23 = ABD23_Inv{1};
beta23 = ABD23_Inv{2};
delta23 = ABD23_Inv{3};


%%Predefine loop conditions

strcond23a = 1;
strcond23b = 1;
strcond23c = 1;
%Max bending is highest loading condition
%Max bending happens at top/bottom of the beam, where shear is 0
N23 = [0; 0; 0]; %lbs
M23 = [0; 1; 0]; %lbs*in

S2 = [1/E1a, -nu21a/E2a, 0; -nu12a/E1a, 1/E2a, 0; 0, 0, 1/G12a];
S3 = [1/E1b, -nu21b/E2b, 0; -nu12b/E1b, 1/E2b, 0; 0, 0, 1/G12b];

while strcond23a == 1 && strcond23b == 1 && strcond23c == 1
    
    %Define in-plane strains (eps0) and plate curvatures (kap)
    eps023 = alpha23*N23 + beta23*M23;
    kap23 = transpose(beta23)*N23 + delta23*M23;
    
    %Global Strains
    eps23G = cell(length(zvec23), 1);
    %Local Strains
    eps23L = cell(length(zvec23), 1);
    %Local Stresses
    sig23L = cell(length(zvec1), 1);

    for i = 1:length(zvec23)
        eps23G{i} = eps023 + zvec23(i)*kap23;
        eps23L{i} = GtoL_epsMatrix(eps23G{i}, thetavec23(i));
        eps23L{i} = cell2mat(eps23L{i});

        %Strength Criterion for Carbon Fiber Sections
        if i == 1 || i == 3 || i == 6 || i == 8 || i == 9 || i == 11 || i == 14 || i == 16
            sig23L{i} = S2\eps23L{i};
            
            %Longitudinal Failure (Tension or Compression)
            if abs(sig23L{i}(1)) >= F1t_a || abs(sig23L{i}(1)) >= F1c_a
                strcond23a = 0;
                break
            end
    
            %Transverse Failure (Tension or Compression)
            if abs(sig23L{i}(2)) >= F2t_a || abs(sig23L{i}(2)) >= F2c_a
                strcond23b = 0;
                break
            end
    
            %In-Plane Shear Failure
            if abs(sig23L{i}(3)) >= F12su_a
                strcond23c = 0;
                break
            end
        %Strength Criterion for Fiberglass sections
        else 
            sig23L{i} = S3\eps23L{i};
            
            %Longitudinal Failure (Tension or Compression)
            if abs(sig23L{i}(1)) >= F1t_b || abs(sig23L{i}(1)) >= F1c_b
                strcond1a = 0;
                break
            end
    
            %Transverse Failure (Tension or Compression)
            if abs(sig23L{i}(2)) >= F2t_b || abs(sig23L{i}(2)) >= F2c_b
                strcond23b = 0;
                break
            end
    
            %In-Plane Shear Failure
            if abs(sig23L{i}(3)) >= F12su_b
                strcond23c = 0;
                break
            end
        end
    end

    M23 = M23 + [0; 1; 0];

end